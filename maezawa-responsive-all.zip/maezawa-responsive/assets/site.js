'use strict';
const input = document.querySelector('#pdf-search');
if (input) {
  const items = Array.from(document.querySelectorAll('#pdf-list .pdf-item'));
  const normalized = items.map(item => item.textContent.normalize('NFKC').toLocaleLowerCase('ja'));
  const count = document.querySelector('#pdf-count');
  const empty = document.querySelector('#pdf-empty');
  const filter = () => {
    const words = input.value.normalize('NFKC').toLocaleLowerCase('ja').trim().split(/\s+/).filter(Boolean);
    let visible = 0;
    items.forEach((item, i) => {
      const matches = words.every(word => normalized[i].includes(word));
      item.hidden = !matches;
      if (matches) visible++;
    });
    count.textContent = `${items.length}件中 ${visible}件の資料`;
    empty.hidden = visible > 0;
  };
  input.addEventListener('input', filter);
  window.addEventListener('pageshow', filter);
}
