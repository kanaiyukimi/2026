'use strict';
const input = document.querySelector('#pdf-search');
if (input) {
  const items = Array.from(document.querySelectorAll('#pdf-list .pdf-item'));
  const normalized = items.map(item => item.textContent.normalize('NFKC').toLocaleLowerCase('ja'));
  const count = document.querySelector('#pdf-count');
  const empty = document.querySelector('#pdf-empty');
  const filter = () => {
    const words = input.value.normalize('NFKC').toLocaleLowerCase('ja').trim().split(/\s+/).filter(Boolean);
    let visible = 0;
    items.forEach((item, i) => {
      const matches = words.every(word => normalized[i].includes(word));
      item.hidden = !matches;
      if (matches) visible++;
    });
    count.textContent = `${items.length}件中 ${visible}件の資料`;
    empty.hidden = visible > 0;
  };
  input.addEventListener('input', filter);
  window.addEventListener('pageshow', filter);
}

// Non-modal disclosure navigation. Native Tab order remains available.
const menuToggle = document.querySelector('.menu-toggle');
const globalNavigation = document.querySelector('#global-navigation');
if (menuToggle && globalNavigation) {
  const mobileViewport = window.matchMedia('(max-width: 680px)');
  const setMenuOpen = (open) => {
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'メニューを閉じる' : 'メニューを開く');
    menuToggle.querySelector('.menu-label').textContent = open ? '閉じる' : 'メニュー';
    globalNavigation.classList.toggle('is-open', open);
    if (!open) globalNavigation.querySelectorAll('details').forEach(category => { category.open = false; });
  };
  menuToggle.addEventListener('click', () => {
    setMenuOpen(menuToggle.getAttribute('aria-expanded') !== 'true');
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && mobileViewport.matches && menuToggle.getAttribute('aria-expanded') === 'true') {
      setMenuOpen(false);
      menuToggle.focus();
    }
  });
  globalNavigation.addEventListener('click', (event) => {
    if (mobileViewport.matches && event.target.closest('a')) setMenuOpen(false);
  });
  mobileViewport.addEventListener('change', () => {
    const focusWasInMenu = globalNavigation.contains(document.activeElement);
    const focusWasOnToggle = document.activeElement === menuToggle;
    setMenuOpen(false);
    if (mobileViewport.matches && focusWasInMenu) menuToggle.focus();
    else if (!mobileViewport.matches && focusWasOnToggle) globalNavigation.querySelector('a').focus();
  });
  window.addEventListener('pageshow', () => setMenuOpen(false));
  document.documentElement.classList.add('js');
}
